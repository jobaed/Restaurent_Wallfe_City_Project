-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 14, 2022 at 04:32 PM
-- Server version: 5.7.33
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `userName`, `password`) VALUES
(1, 'ABDELAZIZ AZAKAF', 'admin@mail.com', 'ec292f0bf9c0387976ebab26ae2e8f3a');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` longtext NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'deactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `contact_information`
--

CREATE TABLE `contact_information` (
  `id` int(11) NOT NULL,
  `restName` varchar(255) NOT NULL,
  `road` varchar(255) NOT NULL,
  `area` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `callText` varchar(255) NOT NULL,
  `callNumber` varchar(30) NOT NULL,
  `emailText` varchar(255) NOT NULL,
  `emailAdd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_information`
--

INSERT INTO `contact_information` (`id`, `restName`, `road`, `area`, `country`, `callText`, `callNumber`, `emailText`, `emailAdd`) VALUES
(1, 'WAFFLE CITY', 'Magasin 07 Founty', ' 13 - Agadir', 'Morocco', 'Call Us:', '0525088865', 'Send Us e-Mail:', 'wafflecityagadir@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `follow`
--

CREATE TABLE `follow` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `follow`
--

INSERT INTO `follow` (`id`, `image`, `url`) VALUES
(9, 'Instagram.jpg', 'https://www.instagram.com/wafflecity_agadir/'),
(11, 'TikTok.jpg', 'https://www.tiktok.com/@wafflecity_agadir'),
(12, 'Whatsapp.jpg', 'https://wa.me/qr/PR73B2ALI3RDI1');

-- --------------------------------------------------------

--
-- Table structure for table `footertext`
--

CREATE TABLE `footertext` (
  `id` int(11) NOT NULL,
  `text` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `footertext`
--

INSERT INTO `footertext` (`id`, `text`) VALUES
(1, '2022 - Tout droit réservé Waffle City™');

-- --------------------------------------------------------

--
-- Table structure for table `footer_social`
--

CREATE TABLE `footer_social` (
  `id` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `fontawesome` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `footer_social`
--

INSERT INTO `footer_social` (`id`, `url`, `fontawesome`) VALUES
(1, 'https://www.facebook.com', 'fa-brands fa-facebook-f'),
(2, 'http:www.youtube.com', 'fa-brands fa-youtube'),
(3, 'http://www.twiter.com', 'fa-brands fa-twitter');

-- --------------------------------------------------------

--
-- Table structure for table `gallary`
--

CREATE TABLE `gallary` (
  `id` int(11) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gallary`
--

INSERT INTO `gallary` (`id`, `img`) VALUES
(30, 'Photo-SiteWeb-12.jpg'),
(31, 'Photo-SiteWeb-11.jpg'),
(32, 'Photo-SiteWeb-10.jpg'),
(33, 'Photo-SiteWeb-9.jpg'),
(34, 'Photo-SiteWeb-7.jpg'),
(35, 'Photo-SiteWeb-6.jpg'),
(36, 'Photo-SiteWeb-5.jpg'),
(37, 'Photo-SiteWeb-4.jpg'),
(38, 'Photo-SiteWeb-3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `header`
--

CREATE TABLE `header` (
  `id` int(11) NOT NULL,
  `textOne` varchar(255) NOT NULL,
  `numberOne` varchar(255) NOT NULL,
  `textTwo` varchar(255) NOT NULL,
  `numberTwo` varchar(255) NOT NULL,
  `callText` varchar(255) NOT NULL,
  `callNumber` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `productBottomHeading` varchar(255) NOT NULL,
  `ProductBottomText` longtext NOT NULL,
  `topFooterLogo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `header`
--

INSERT INTO `header` (`id`, `textOne`, `numberOne`, `textTwo`, `numberTwo`, `callText`, `callNumber`, `logo`, `productBottomHeading`, `ProductBottomText`, `topFooterLogo`) VALUES
(1, 'Magasin 07 Founty 13 - Agadir', '0525088865', 'SALAM CITY', '05282-77777', 'Do not hesitate to call us!', '05282-99999', 'mistercook-logo.jpg', 'Waffle City', 'Our establishment offers you a wide choice of various and varied taste pleasures: salty, sweet, hot, cold, come and discover our dishes!', 'aplus.png');

-- --------------------------------------------------------

--
-- Table structure for table `menucard`
--

CREATE TABLE `menucard` (
  `id` int(11) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menucard`
--

INSERT INTO `menucard` (`id`, `img`) VALUES
(2, '1.jpg'),
(3, '2.jpg'),
(4, '3.jpg'),
(5, '4.jpg'),
(6, '5.jpg'),
(8, '7.jpg'),
(9, '8.jpg'),
(18, 'FB_IMG_1602530909881.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `our_history`
--

CREATE TABLE `our_history` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `history` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `our_history`
--

INSERT INTO `our_history` (`id`, `title`, `history`) VALUES
(1, 'Our History', 'Mister cook, created in 2006 in the heart of the capital of Souss, is the first fast food chain in Agadir. This is the story of a brand that has grown and enjoyed dazzling success over the years. The secret of this brilliant growth is our great know-how unanimously praised by our dear customers who testify to the quality of our products and our services. On the other hand, we pay particular attention to the training of our team members who are the standard-bearers of our know-how. Finally, Mister Cook is constantly looking for novelty and creativity in order to offer its loyal customers a wide range of high quality products. The satisfaction of our customers is our priority.');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `foodImage` varchar(255) NOT NULL,
  `foodName` varchar(255) NOT NULL,
  `cate_id` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `priceCurrency` varchar(255) NOT NULL,
  `Details` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `foodImage`, `foodName`, `cate_id`, `price`, `priceCurrency`, `Details`) VALUES
(1, 'chicken.jpg', 'Chicken', '1', '25,00', 'USD', '. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(2, 'cheesy.jpg', 'Duplex', '3', '30.00', 'USD', 's a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, som'),
(3, 'pasta-fruit-de-mer.jpg', 'Pasta', '3', '40.00', 'USD', 's a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, som'),
(4, 'shawarma.jpg', 'Indian', '3', '26.00', 'USD', 'ong established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their inf'),
(5, 'pepperoni.jpg', 'Papparoni', '10', '35.00', 'USD', 'ong established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their inf'),
(6, 'crepe-nutella-banane.jpg', 'Nuttella Banana', '2', '30.00', 'USD', 'ong established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their inf'),
(7, 'mr-steak.jpg', 'Mr. Steak', '2', '45.00', 'USD', 'ong established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their inf'),
(8, 'avocat.jpg', 'Avocat', '1', '50.00', 'USD', 'ong established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their inf');

-- --------------------------------------------------------

--
-- Table structure for table `product_cate`
--

CREATE TABLE `product_cate` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `descrp` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_cate`
--

INSERT INTO `product_cate` (`id`, `name`, `img`, `descrp`) VALUES
(1, 'Salade', 'salade.jpg', 'A desire for freshness in summer? a light meal ? a starter before a good dish? visit all our                             salads!'),
(2, 'Burgers', 'burgers.jpg', 'A desire for freshness in summer? a light meal ? a starter before a good dish? visit all our                             salads!'),
(3, 'Pizza', 'pizzas.jpg', 'A desire for freshness in summer? a light meal ? a starter before a good dish? visit all our                             salads!'),
(4, 'Sandwiches', 'sandwiches.jpg', 'boolean attribute on an input to prevent modification of the input’s value. Read-only inputs appear lighter (just like disabled inputs), but retain the standard cursor.'),
(5, 'Pasta', 'pastaBox.jpg', 'Pasta is Checkboxes and radios use are built to support HTML-based form validation and provide concise, accessible labels. As such, our'),
(6, 'Assiettes', 'assiettes.jpg', 'Checkboxes and radios use are built to support HTML-based form validation and provide concise, accessible labels. As such, our'),
(7, 'Tacos', 'tacos.jpg', 'Tacos is Checkboxes and radios use are built to support HTML-based form validation and provide concise, accessible labels. As such, our'),
(8, 'Gateaux', 'gateaux.jpg', 'boolean attribute on an input to prevent modification of the input’s value. Read-only inputs appear lighter (just like disabled inputs), but retain the standard cursor.'),
(9, 'TexMex', 'texMex.jpg', 'Lorem Checkboxes and radios use are built to support HTML-based form validation and provide concise, accessible labels. As such, our'),
(10, 'Glaces', 'glaces.jpg', 'Checkboxes and radios use are built to support HTML-based form validation and provide concise, accessible labels. As such, our');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_information`
--
ALTER TABLE `contact_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `follow`
--
ALTER TABLE `follow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footertext`
--
ALTER TABLE `footertext`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footer_social`
--
ALTER TABLE `footer_social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallary`
--
ALTER TABLE `gallary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `header`
--
ALTER TABLE `header`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menucard`
--
ALTER TABLE `menucard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `our_history`
--
ALTER TABLE `our_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_cate`
--
ALTER TABLE `product_cate`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_information`
--
ALTER TABLE `contact_information`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `follow`
--
ALTER TABLE `follow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `footertext`
--
ALTER TABLE `footertext`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `footer_social`
--
ALTER TABLE `footer_social`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `gallary`
--
ALTER TABLE `gallary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `header`
--
ALTER TABLE `header`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `menucard`
--
ALTER TABLE `menucard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `our_history`
--
ALTER TABLE `our_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `product_cate`
--
ALTER TABLE `product_cate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
